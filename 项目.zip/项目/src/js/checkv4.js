function delVistGoods() {
	//var form = document.deleteForm;
	//form.submit();
	location.href="/info/calDel_vist.jsp";
}

function addCheckGoods(showType,selectCnt,url,gcd) {
	var form = document.moveToaddCart;
	
	
	if(showType=='2'){
		
		form.gcnt.value=$("#"+ selectCnt).val();
	}
	
	form.returnurl.value=url;
	form.gcd.value=gcd;
	form.submit();
	
}