    window.Swiper = Swiper;
})();