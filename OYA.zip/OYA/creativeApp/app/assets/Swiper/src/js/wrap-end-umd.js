	return Swiper;
}));